--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.4
-- Dumped by pg_dump version 10.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.ventas DROP CONSTRAINT ventas_idusuario_fkey;
ALTER TABLE ONLY public.ventas DROP CONSTRAINT ventas_idtipopago_fkey;
ALTER TABLE ONLY public.ventas DROP CONSTRAINT ventas_idcliente_fkey;
ALTER TABLE ONLY public.usuarios DROP CONSTRAINT usuarios_idtipo_fkey;
ALTER TABLE ONLY public.reportevendedor DROP CONSTRAINT reportevendedor_idvendedor_fkey;
ALTER TABLE ONLY public.reporteclientemasingresos DROP CONSTRAINT reporteclientemasingresos_idcliente_fkey;
ALTER TABLE ONLY public.reportearticulo DROP CONSTRAINT reportearticulo_idarticulo_fkey;
ALTER TABLE ONLY public.peticiones DROP CONSTRAINT peticiones_localorigen_fkey;
ALTER TABLE ONLY public.peticiones DROP CONSTRAINT peticiones_localdestino_fkey;
ALTER TABLE ONLY public.peticiones DROP CONSTRAINT peticiones_idusuario_fkey;
ALTER TABLE ONLY public.peticiones DROP CONSTRAINT peticiones_idarticulo_fkey;
ALTER TABLE ONLY public.pagos DROP CONSTRAINT pagos_idusuario_fkey;
ALTER TABLE ONLY public.pagos DROP CONSTRAINT pagos_idtipopago_fkey;
ALTER TABLE ONLY public.pagos DROP CONSTRAINT pagos_idproveedor_fkey;
ALTER TABLE ONLY public.logventa DROP CONSTRAINT logventa_idventa_fkey;
ALTER TABLE ONLY public.logpago DROP CONSTRAINT logpago_idpago_fkey;
ALTER TABLE ONLY public.logcotizacion DROP CONSTRAINT logcotizacion_idcotizacion_fkey;
ALTER TABLE ONLY public.logcliente DROP CONSTRAINT logcliente_idcliente_fkey;
ALTER TABLE ONLY public.inventario DROP CONSTRAINT inventario_idlocal_fkey;
ALTER TABLE ONLY public.inventario DROP CONSTRAINT inventario_idarticulo_fkey;
ALTER TABLE ONLY public.establecimientos DROP CONSTRAINT establecimientos_idtipo_fkey;
ALTER TABLE ONLY public.establecimientos DROP CONSTRAINT establecimientos_encargado_fkey;
ALTER TABLE ONLY public.descripcionventa DROP CONSTRAINT descripcionventa_idventa_fkey;
ALTER TABLE ONLY public.descripcionventa DROP CONSTRAINT descripcionventa_idarticulo_fkey;
ALTER TABLE ONLY public.descripcionpago DROP CONSTRAINT descripcionpago_idpago_fkey;
ALTER TABLE ONLY public.descripcionpago DROP CONSTRAINT descripcionpago_idarticulo_fkey;
ALTER TABLE ONLY public.descripcioncotizacion DROP CONSTRAINT descripcioncotizacion_idcotizacion_fkey;
ALTER TABLE ONLY public.descripcioncotizacion DROP CONSTRAINT descripcioncotizacion_idarticulo_fkey;
ALTER TABLE ONLY public.cotizacion DROP CONSTRAINT cotizacion_idusuario_fkey;
ALTER TABLE ONLY public.cotizacion DROP CONSTRAINT cotizacion_idcliente_fkey;
ALTER TABLE ONLY public.clientepersona DROP CONSTRAINT clientepersona_idcliente_fkey;
ALTER TABLE ONLY public.clienteempresa DROP CONSTRAINT clienteempresa_idcliente_fkey;
ALTER TABLE ONLY public.articulos DROP CONSTRAINT articulos_idtipoarticulo_fkey;
ALTER TABLE ONLY public.articulos DROP CONSTRAINT articulos_idmarca_fkey;
ALTER TABLE ONLY public.ventas DROP CONSTRAINT ventas_pkey;
ALTER TABLE ONLY public.usuarios DROP CONSTRAINT usuarios_pkey;
ALTER TABLE ONLY public.usuarios DROP CONSTRAINT usuarios_cedula_key;
ALTER TABLE ONLY public.tipousuario DROP CONSTRAINT tipousuario_pkey;
ALTER TABLE ONLY public.tipousuario DROP CONSTRAINT tipousuario_nombre_key;
ALTER TABLE ONLY public.tipopago DROP CONSTRAINT tipopago_pkey;
ALTER TABLE ONLY public.tipoestablecimiento DROP CONSTRAINT tipoestablecimiento_pkey;
ALTER TABLE ONLY public.tipoarticulo DROP CONSTRAINT tipoarticulo_pkey;
ALTER TABLE ONLY public.tipoarticulo DROP CONSTRAINT tipoarticulo_nombre_key;
ALTER TABLE ONLY public.reportevendedor DROP CONSTRAINT reportevendedor_pkey;
ALTER TABLE ONLY public.reporteclientemasingresos DROP CONSTRAINT reporteclientemasingresos_pkey;
ALTER TABLE ONLY public.reportearticulo DROP CONSTRAINT reportearticulo_pkey;
ALTER TABLE ONLY public.proveedores DROP CONSTRAINT proveedores_pkey;
ALTER TABLE ONLY public.peticiones DROP CONSTRAINT peticiones_pkey;
ALTER TABLE ONLY public.pagos DROP CONSTRAINT pagos_pkey;
ALTER TABLE ONLY public.marcas DROP CONSTRAINT marcas_pkey;
ALTER TABLE ONLY public.marcas DROP CONSTRAINT marcas_nombre_key;
ALTER TABLE ONLY public.logventa DROP CONSTRAINT logventa_pkey;
ALTER TABLE ONLY public.logpago DROP CONSTRAINT logpago_pkey;
ALTER TABLE ONLY public.logcotizacion DROP CONSTRAINT logcotizacion_pkey;
ALTER TABLE ONLY public.logcliente DROP CONSTRAINT logcliente_pkey;
ALTER TABLE ONLY public.inventario DROP CONSTRAINT inventario_pkey;
ALTER TABLE ONLY public.establecimientos DROP CONSTRAINT establecimientos_pkey;
ALTER TABLE ONLY public.descripcionventa DROP CONSTRAINT descripcionventa_pkey;
ALTER TABLE ONLY public.descripcionpago DROP CONSTRAINT descripcionpago_pkey;
ALTER TABLE ONLY public.descripcioncotizacion DROP CONSTRAINT descripcioncotizacion_pkey;
ALTER TABLE ONLY public.cotizacion DROP CONSTRAINT cotizacion_pkey;
ALTER TABLE ONLY public.clientes DROP CONSTRAINT clientes_pkey;
ALTER TABLE ONLY public.clientepersona DROP CONSTRAINT clientepersona_pkey;
ALTER TABLE ONLY public.clienteempresa DROP CONSTRAINT clienteempresa_pkey;
ALTER TABLE ONLY public.articulos DROP CONSTRAINT articulos_pkey;
ALTER TABLE public.ventas ALTER COLUMN idventa DROP DEFAULT;
ALTER TABLE public.usuarios ALTER COLUMN idusuario DROP DEFAULT;
ALTER TABLE public.tipousuario ALTER COLUMN idtipo DROP DEFAULT;
ALTER TABLE public.tipopago ALTER COLUMN idtipo DROP DEFAULT;
ALTER TABLE public.tipoestablecimiento ALTER COLUMN idtipo DROP DEFAULT;
ALTER TABLE public.tipoarticulo ALTER COLUMN idtipoart DROP DEFAULT;
ALTER TABLE public.reportevendedor ALTER COLUMN idreportevendedor DROP DEFAULT;
ALTER TABLE public.reporteclientemasingresos ALTER COLUMN idreportecliente DROP DEFAULT;
ALTER TABLE public.reportearticulo ALTER COLUMN idreportearticulo DROP DEFAULT;
ALTER TABLE public.proveedores ALTER COLUMN idproveedor DROP DEFAULT;
ALTER TABLE public.peticiones ALTER COLUMN idpeticion DROP DEFAULT;
ALTER TABLE public.pagos ALTER COLUMN idpago DROP DEFAULT;
ALTER TABLE public.marcas ALTER COLUMN idmarca DROP DEFAULT;
ALTER TABLE public.logventa ALTER COLUMN idlog DROP DEFAULT;
ALTER TABLE public.logpago ALTER COLUMN idlog DROP DEFAULT;
ALTER TABLE public.logcotizacion ALTER COLUMN idlog DROP DEFAULT;
ALTER TABLE public.logcliente ALTER COLUMN idlog DROP DEFAULT;
ALTER TABLE public.inventario ALTER COLUMN idinventario DROP DEFAULT;
ALTER TABLE public.establecimientos ALTER COLUMN idestablecimiento DROP DEFAULT;
ALTER TABLE public.descripcionventa ALTER COLUMN iddescripcion DROP DEFAULT;
ALTER TABLE public.descripcionpago ALTER COLUMN iddescripcion DROP DEFAULT;
ALTER TABLE public.descripcioncotizacion ALTER COLUMN iddescripcion DROP DEFAULT;
ALTER TABLE public.cotizacion ALTER COLUMN idcotizacion DROP DEFAULT;
ALTER TABLE public.clientes ALTER COLUMN idcliente DROP DEFAULT;
ALTER TABLE public.articulos ALTER COLUMN idarticulo DROP DEFAULT;
DROP SEQUENCE public.ventas_idventa_seq;
DROP TABLE public.ventas;
DROP SEQUENCE public.usuarios_idusuario_seq;
DROP TABLE public.usuarios;
DROP SEQUENCE public.tipousuario_idtipo_seq;
DROP TABLE public.tipousuario;
DROP SEQUENCE public.tipopago_idtipo_seq;
DROP TABLE public.tipopago;
DROP SEQUENCE public.tipoestablecimiento_idtipo_seq;
DROP TABLE public.tipoestablecimiento;
DROP SEQUENCE public.tipoarticulo_idtipoart_seq;
DROP TABLE public.tipoarticulo;
DROP SEQUENCE public.reportevendedor_idreportevendedor_seq;
DROP TABLE public.reportevendedor;
DROP SEQUENCE public.reporteclientemasingresos_idreportecliente_seq;
DROP TABLE public.reporteclientemasingresos;
DROP SEQUENCE public.reportearticulo_idreportearticulo_seq;
DROP TABLE public.reportearticulo;
DROP SEQUENCE public.proveedores_idproveedor_seq;
DROP TABLE public.proveedores;
DROP SEQUENCE public.peticiones_idpeticion_seq;
DROP TABLE public.peticiones;
DROP SEQUENCE public.pagos_idpago_seq;
DROP TABLE public.pagos;
DROP SEQUENCE public.marcas_idmarca_seq;
DROP TABLE public.marcas;
DROP SEQUENCE public.logventa_idlog_seq;
DROP TABLE public.logventa;
DROP SEQUENCE public.logpago_idlog_seq;
DROP TABLE public.logpago;
DROP SEQUENCE public.logcotizacion_idlog_seq;
DROP TABLE public.logcotizacion;
DROP SEQUENCE public.logcliente_idlog_seq;
DROP TABLE public.logcliente;
DROP SEQUENCE public.inventario_idinventario_seq;
DROP TABLE public.inventario;
DROP SEQUENCE public.establecimientos_idestablecimiento_seq;
DROP TABLE public.establecimientos;
DROP SEQUENCE public.descripcionventa_iddescripcion_seq;
DROP TABLE public.descripcionventa;
DROP SEQUENCE public.descripcionpago_iddescripcion_seq;
DROP TABLE public.descripcionpago;
DROP SEQUENCE public.descripcioncotizacion_iddescripcion_seq;
DROP TABLE public.descripcioncotizacion;
DROP SEQUENCE public.cotizacion_idcotizacion_seq;
DROP TABLE public.cotizacion;
DROP SEQUENCE public.clientes_idcliente_seq;
DROP TABLE public.clientes;
DROP TABLE public.clientepersona;
DROP TABLE public.clienteempresa;
DROP SEQUENCE public.articulos_idarticulo_seq;
DROP TABLE public.articulos;
DROP FUNCTION public."logVenta"(venta integer);
DROP FUNCTION public."logPago"(pago integer);
DROP FUNCTION public."logCotizacion"(cotizacion integer);
DROP FUNCTION public."logCliente"(cliente integer);
DROP FUNCTION public."getTipoUsuario"(usuario character varying, "contraseña" character varying);
DROP FUNCTION public."agregarUsuario"(nombres character varying, apellidos character varying, "contraseña" character varying, usuario character varying, cedula character varying, idtipo integer);
DROP FUNCTION public."agregarProveedor"(nombre character varying);
DROP FUNCTION public."agregarCotizacion"(descripcion text, idcliente integer, idusuario integer);
DROP FUNCTION public."agregarClientePersona"(idclientepersona character varying, idcliente integer);
DROP FUNCTION public."agregarClienteEmpresa"(idcliente integer, idclienteempresa character varying);
DROP FUNCTION public."agregarCliente"(nombre character varying, direccion character varying, telefono character varying);
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: agregarCliente(character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."agregarCliente"(nombre character varying, direccion character varying, telefono character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$Begin
	INSERT INTO Clientes(Nombre, Direccion, Telefono) 
	VALUES (nombre,direccion,telefono);
END;$$;


ALTER FUNCTION public."agregarCliente"(nombre character varying, direccion character varying, telefono character varying) OWNER TO postgres;

--
-- Name: agregarClienteEmpresa(integer, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."agregarClienteEmpresa"(idcliente integer, idclienteempresa character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$Begin
	INSERT INTO ClienteEmpresa(idClienteEmpresa, idCliente) 
	VALUES (idclienteempresa,idcliente);
END;$$;


ALTER FUNCTION public."agregarClienteEmpresa"(idcliente integer, idclienteempresa character varying) OWNER TO postgres;

--
-- Name: agregarClientePersona(character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."agregarClientePersona"(idclientepersona character varying, idcliente integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$Begin
	INSERT INTO ClientePersona(idClientePersona, idCliente) 
	VALUES (idclientepersona,idcliente);
END;$$;


ALTER FUNCTION public."agregarClientePersona"(idclientepersona character varying, idcliente integer) OWNER TO postgres;

--
-- Name: agregarCotizacion(text, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."agregarCotizacion"(descripcion text, idcliente integer, idusuario integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$Begin
	INSERT INTO Cotizacion(Descripcion,idCliente,idUsuario,Fecha) 
	VALUES (descripcion,idcliente,idusuario,CURDATE());
END;$$;


ALTER FUNCTION public."agregarCotizacion"(descripcion text, idcliente integer, idusuario integer) OWNER TO postgres;

--
-- Name: agregarProveedor(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."agregarProveedor"(nombre character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$Begin
	INSERT INTO Proveedores(Nombre) 
	VALUES (nombre);
END;$$;


ALTER FUNCTION public."agregarProveedor"(nombre character varying) OWNER TO postgres;

--
-- Name: agregarUsuario(character varying, character varying, character varying, character varying, character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."agregarUsuario"(nombres character varying, apellidos character varying, "contraseña" character varying, usuario character varying, cedula character varying, idtipo integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$Begin
	INSERT INTO Usuarios(Usuario,Contraseña,Cedula,Nombres,Apellidos,idTipo)
	VALUES (usuario,contraseña,cedula,nombres,apellidos,idtipo);
END;$$;


ALTER FUNCTION public."agregarUsuario"(nombres character varying, apellidos character varying, "contraseña" character varying, usuario character varying, cedula character varying, idtipo integer) OWNER TO postgres;

--
-- Name: getTipoUsuario(character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."getTipoUsuario"(usuario character varying, "contraseña" character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$Begin
	SELECT idTipo FROM Usuarios u WHERE u.usuario=usuario AND u.contraseña=contrasenia;
END;$$;


ALTER FUNCTION public."getTipoUsuario"(usuario character varying, "contraseña" character varying) OWNER TO postgres;

--
-- Name: logCliente(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."logCliente"(cliente integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$Begin
	INSERT INTO LogCliente(idCliente, Fecha, Hora) 
	VALUES (Cliente,CURDATE(),CURTIME());
END;$$;


ALTER FUNCTION public."logCliente"(cliente integer) OWNER TO postgres;

--
-- Name: logCotizacion(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."logCotizacion"(cotizacion integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$ Begin
	INSERT INTO LogCotizacion(idCotizacion, Fecha, Hora) 
	VALUES (Cotizacion,CURDATE(),CURTIME());
END;$$;


ALTER FUNCTION public."logCotizacion"(cotizacion integer) OWNER TO postgres;

--
-- Name: logPago(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."logPago"(pago integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$ Begin
	INSERT INTO LogPago(idPago, Fecha, Hora) 
	VALUES (Pago,CURDATE(),CURTIME());
END;$$;


ALTER FUNCTION public."logPago"(pago integer) OWNER TO postgres;

--
-- Name: logVenta(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."logVenta"(venta integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$Begin
	INSERT INTO LogVenta(idVenta, Fecha, Hora) 
	VALUES (Venta,CURDATE(),CURTIME());
END;$$;


ALTER FUNCTION public."logVenta"(venta integer) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: articulos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.articulos (
    idarticulo integer NOT NULL,
    nombremodelo character varying(45) NOT NULL,
    idtipoarticulo integer NOT NULL,
    idmarca integer NOT NULL,
    precio double precision NOT NULL
);


ALTER TABLE public.articulos OWNER TO postgres;

--
-- Name: articulos_idarticulo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.articulos_idarticulo_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.articulos_idarticulo_seq OWNER TO postgres;

--
-- Name: articulos_idarticulo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.articulos_idarticulo_seq OWNED BY public.articulos.idarticulo;


--
-- Name: clienteempresa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clienteempresa (
    idclienteempresa character varying(13) NOT NULL,
    idcliente integer NOT NULL
);


ALTER TABLE public.clienteempresa OWNER TO postgres;

--
-- Name: clientepersona; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clientepersona (
    idclientepersona character varying(10) NOT NULL,
    idcliente integer NOT NULL
);


ALTER TABLE public.clientepersona OWNER TO postgres;

--
-- Name: clientes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clientes (
    idcliente integer NOT NULL,
    nombre character varying(60) DEFAULT NULL::character varying,
    direccion character varying(50) DEFAULT NULL::character varying,
    correo character varying(35) DEFAULT NULL::character varying,
    telefono character varying(20) DEFAULT NULL::character varying
);


ALTER TABLE public.clientes OWNER TO postgres;

--
-- Name: clientes_idcliente_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.clientes_idcliente_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.clientes_idcliente_seq OWNER TO postgres;

--
-- Name: clientes_idcliente_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.clientes_idcliente_seq OWNED BY public.clientes.idcliente;


--
-- Name: cotizacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cotizacion (
    idcotizacion integer NOT NULL,
    descripcion text,
    idcliente integer NOT NULL,
    idusuario integer NOT NULL,
    fecha date NOT NULL
);


ALTER TABLE public.cotizacion OWNER TO postgres;

--
-- Name: cotizacion_idcotizacion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cotizacion_idcotizacion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cotizacion_idcotizacion_seq OWNER TO postgres;

--
-- Name: cotizacion_idcotizacion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cotizacion_idcotizacion_seq OWNED BY public.cotizacion.idcotizacion;


--
-- Name: descripcioncotizacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.descripcioncotizacion (
    iddescripcion integer NOT NULL,
    idcotizacion integer NOT NULL,
    idarticulo integer NOT NULL,
    cantidad integer NOT NULL,
    total double precision NOT NULL
);


ALTER TABLE public.descripcioncotizacion OWNER TO postgres;

--
-- Name: descripcioncotizacion_iddescripcion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.descripcioncotizacion_iddescripcion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.descripcioncotizacion_iddescripcion_seq OWNER TO postgres;

--
-- Name: descripcioncotizacion_iddescripcion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.descripcioncotizacion_iddescripcion_seq OWNED BY public.descripcioncotizacion.iddescripcion;


--
-- Name: descripcionpago; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.descripcionpago (
    iddescripcion integer NOT NULL,
    idpago integer NOT NULL,
    idarticulo integer NOT NULL,
    cantidad integer NOT NULL,
    total double precision NOT NULL
);


ALTER TABLE public.descripcionpago OWNER TO postgres;

--
-- Name: descripcionpago_iddescripcion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.descripcionpago_iddescripcion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.descripcionpago_iddescripcion_seq OWNER TO postgres;

--
-- Name: descripcionpago_iddescripcion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.descripcionpago_iddescripcion_seq OWNED BY public.descripcionpago.iddescripcion;


--
-- Name: descripcionventa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.descripcionventa (
    iddescripcion integer NOT NULL,
    idventa integer NOT NULL,
    idarticulo integer NOT NULL,
    cantidad integer NOT NULL,
    total double precision NOT NULL
);


ALTER TABLE public.descripcionventa OWNER TO postgres;

--
-- Name: descripcionventa_iddescripcion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.descripcionventa_iddescripcion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.descripcionventa_iddescripcion_seq OWNER TO postgres;

--
-- Name: descripcionventa_iddescripcion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.descripcionventa_iddescripcion_seq OWNED BY public.descripcionventa.iddescripcion;


--
-- Name: establecimientos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.establecimientos (
    idestablecimiento integer NOT NULL,
    idtipo integer NOT NULL,
    nombre character varying(25) DEFAULT NULL::character varying,
    direccion character varying(50) DEFAULT NULL::character varying,
    encargado integer NOT NULL
);


ALTER TABLE public.establecimientos OWNER TO postgres;

--
-- Name: establecimientos_idestablecimiento_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.establecimientos_idestablecimiento_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.establecimientos_idestablecimiento_seq OWNER TO postgres;

--
-- Name: establecimientos_idestablecimiento_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.establecimientos_idestablecimiento_seq OWNED BY public.establecimientos.idestablecimiento;


--
-- Name: inventario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventario (
    idinventario integer NOT NULL,
    idarticulo integer NOT NULL,
    cantidad integer NOT NULL,
    idlocal integer NOT NULL
);


ALTER TABLE public.inventario OWNER TO postgres;

--
-- Name: inventario_idinventario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventario_idinventario_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.inventario_idinventario_seq OWNER TO postgres;

--
-- Name: inventario_idinventario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventario_idinventario_seq OWNED BY public.inventario.idinventario;


--
-- Name: logcliente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.logcliente (
    idlog integer NOT NULL,
    idcliente integer NOT NULL,
    fecha date,
    hora time without time zone
);


ALTER TABLE public.logcliente OWNER TO postgres;

--
-- Name: logcliente_idlog_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.logcliente_idlog_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.logcliente_idlog_seq OWNER TO postgres;

--
-- Name: logcliente_idlog_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.logcliente_idlog_seq OWNED BY public.logcliente.idlog;


--
-- Name: logcotizacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.logcotizacion (
    idlog integer NOT NULL,
    idcotizacion integer NOT NULL,
    fecha date,
    hora time without time zone
);


ALTER TABLE public.logcotizacion OWNER TO postgres;

--
-- Name: logcotizacion_idlog_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.logcotizacion_idlog_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.logcotizacion_idlog_seq OWNER TO postgres;

--
-- Name: logcotizacion_idlog_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.logcotizacion_idlog_seq OWNED BY public.logcotizacion.idlog;


--
-- Name: logpago; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.logpago (
    idlog integer NOT NULL,
    idpago integer NOT NULL,
    fecha date,
    hora time without time zone
);


ALTER TABLE public.logpago OWNER TO postgres;

--
-- Name: logpago_idlog_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.logpago_idlog_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.logpago_idlog_seq OWNER TO postgres;

--
-- Name: logpago_idlog_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.logpago_idlog_seq OWNED BY public.logpago.idlog;


--
-- Name: logventa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.logventa (
    idlog integer NOT NULL,
    idventa integer NOT NULL,
    fecha date,
    hora time without time zone
);


ALTER TABLE public.logventa OWNER TO postgres;

--
-- Name: logventa_idlog_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.logventa_idlog_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.logventa_idlog_seq OWNER TO postgres;

--
-- Name: logventa_idlog_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.logventa_idlog_seq OWNED BY public.logventa.idlog;


--
-- Name: marcas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marcas (
    idmarca integer NOT NULL,
    nombre character varying(35) NOT NULL
);


ALTER TABLE public.marcas OWNER TO postgres;

--
-- Name: marcas_idmarca_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.marcas_idmarca_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.marcas_idmarca_seq OWNER TO postgres;

--
-- Name: marcas_idmarca_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.marcas_idmarca_seq OWNED BY public.marcas.idmarca;


--
-- Name: pagos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pagos (
    idpago integer NOT NULL,
    descripcion text,
    idproveedor integer NOT NULL,
    idusuario integer NOT NULL,
    idtipopago integer NOT NULL,
    fecha date NOT NULL
);


ALTER TABLE public.pagos OWNER TO postgres;

--
-- Name: pagos_idpago_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pagos_idpago_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pagos_idpago_seq OWNER TO postgres;

--
-- Name: pagos_idpago_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pagos_idpago_seq OWNED BY public.pagos.idpago;


--
-- Name: peticiones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.peticiones (
    idpeticion integer NOT NULL,
    idarticulo integer NOT NULL,
    localorigen integer NOT NULL,
    localdestino integer NOT NULL,
    idusuario integer NOT NULL
);


ALTER TABLE public.peticiones OWNER TO postgres;

--
-- Name: peticiones_idpeticion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.peticiones_idpeticion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.peticiones_idpeticion_seq OWNER TO postgres;

--
-- Name: peticiones_idpeticion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.peticiones_idpeticion_seq OWNED BY public.peticiones.idpeticion;


--
-- Name: proveedores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.proveedores (
    idproveedor integer NOT NULL,
    nombre character varying(50) NOT NULL
);


ALTER TABLE public.proveedores OWNER TO postgres;

--
-- Name: proveedores_idproveedor_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.proveedores_idproveedor_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.proveedores_idproveedor_seq OWNER TO postgres;

--
-- Name: proveedores_idproveedor_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.proveedores_idproveedor_seq OWNED BY public.proveedores.idproveedor;


--
-- Name: reportearticulo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reportearticulo (
    idreportearticulo integer NOT NULL,
    idarticulo integer NOT NULL,
    cantidad integer NOT NULL,
    montototal double precision NOT NULL
);


ALTER TABLE public.reportearticulo OWNER TO postgres;

--
-- Name: reportearticulo_idreportearticulo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reportearticulo_idreportearticulo_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reportearticulo_idreportearticulo_seq OWNER TO postgres;

--
-- Name: reportearticulo_idreportearticulo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reportearticulo_idreportearticulo_seq OWNED BY public.reportearticulo.idreportearticulo;


--
-- Name: reporteclientemasingresos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reporteclientemasingresos (
    idreportecliente integer NOT NULL,
    idcliente integer NOT NULL,
    montopromedio double precision NOT NULL
);


ALTER TABLE public.reporteclientemasingresos OWNER TO postgres;

--
-- Name: reporteclientemasingresos_idreportecliente_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reporteclientemasingresos_idreportecliente_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reporteclientemasingresos_idreportecliente_seq OWNER TO postgres;

--
-- Name: reporteclientemasingresos_idreportecliente_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reporteclientemasingresos_idreportecliente_seq OWNED BY public.reporteclientemasingresos.idreportecliente;


--
-- Name: reportevendedor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reportevendedor (
    idreportevendedor integer NOT NULL,
    idvendedor integer NOT NULL,
    cantidadventas integer NOT NULL,
    montototal double precision NOT NULL
);


ALTER TABLE public.reportevendedor OWNER TO postgres;

--
-- Name: reportevendedor_idreportevendedor_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reportevendedor_idreportevendedor_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reportevendedor_idreportevendedor_seq OWNER TO postgres;

--
-- Name: reportevendedor_idreportevendedor_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reportevendedor_idreportevendedor_seq OWNED BY public.reportevendedor.idreportevendedor;


--
-- Name: tipoarticulo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipoarticulo (
    idtipoart integer NOT NULL,
    nombre character varying(50) NOT NULL
);


ALTER TABLE public.tipoarticulo OWNER TO postgres;

--
-- Name: tipoarticulo_idtipoart_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipoarticulo_idtipoart_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipoarticulo_idtipoart_seq OWNER TO postgres;

--
-- Name: tipoarticulo_idtipoart_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipoarticulo_idtipoart_seq OWNED BY public.tipoarticulo.idtipoart;


--
-- Name: tipoestablecimiento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipoestablecimiento (
    idtipo integer NOT NULL,
    nombre character varying(25)
);


ALTER TABLE public.tipoestablecimiento OWNER TO postgres;

--
-- Name: tipoestablecimiento_idtipo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipoestablecimiento_idtipo_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipoestablecimiento_idtipo_seq OWNER TO postgres;

--
-- Name: tipoestablecimiento_idtipo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipoestablecimiento_idtipo_seq OWNED BY public.tipoestablecimiento.idtipo;


--
-- Name: tipopago; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipopago (
    idtipo integer NOT NULL,
    tipo character varying(30) NOT NULL
);


ALTER TABLE public.tipopago OWNER TO postgres;

--
-- Name: tipopago_idtipo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipopago_idtipo_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipopago_idtipo_seq OWNER TO postgres;

--
-- Name: tipopago_idtipo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipopago_idtipo_seq OWNED BY public.tipopago.idtipo;


--
-- Name: tipousuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipousuario (
    idtipo integer NOT NULL,
    nombre character varying(50) NOT NULL
);


ALTER TABLE public.tipousuario OWNER TO postgres;

--
-- Name: tipousuario_idtipo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipousuario_idtipo_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipousuario_idtipo_seq OWNER TO postgres;

--
-- Name: tipousuario_idtipo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipousuario_idtipo_seq OWNED BY public.tipousuario.idtipo;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuarios (
    idusuario integer NOT NULL,
    "contraseña" character varying(25) NOT NULL,
    idtipo integer NOT NULL,
    nombres character varying(30) DEFAULT NULL::character varying,
    apellidos character varying(30) DEFAULT NULL::character varying,
    cedula character varying(10) NOT NULL,
    fechanacimiento date,
    profesion character varying(30) DEFAULT NULL::character varying,
    correo character varying(35) DEFAULT NULL::character varying,
    usuario character varying(25) NOT NULL
);


ALTER TABLE public.usuarios OWNER TO postgres;

--
-- Name: usuarios_idusuario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuarios_idusuario_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuarios_idusuario_seq OWNER TO postgres;

--
-- Name: usuarios_idusuario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuarios_idusuario_seq OWNED BY public.usuarios.idusuario;


--
-- Name: ventas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ventas (
    idventa integer NOT NULL,
    descripcion text,
    idcliente integer NOT NULL,
    idusuario integer NOT NULL,
    idtipopago integer NOT NULL,
    fecha date NOT NULL
);


ALTER TABLE public.ventas OWNER TO postgres;

--
-- Name: ventas_idventa_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ventas_idventa_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ventas_idventa_seq OWNER TO postgres;

--
-- Name: ventas_idventa_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ventas_idventa_seq OWNED BY public.ventas.idventa;


--
-- Name: articulos idarticulo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulos ALTER COLUMN idarticulo SET DEFAULT nextval('public.articulos_idarticulo_seq'::regclass);


--
-- Name: clientes idcliente; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clientes ALTER COLUMN idcliente SET DEFAULT nextval('public.clientes_idcliente_seq'::regclass);


--
-- Name: cotizacion idcotizacion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cotizacion ALTER COLUMN idcotizacion SET DEFAULT nextval('public.cotizacion_idcotizacion_seq'::regclass);


--
-- Name: descripcioncotizacion iddescripcion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.descripcioncotizacion ALTER COLUMN iddescripcion SET DEFAULT nextval('public.descripcioncotizacion_iddescripcion_seq'::regclass);


--
-- Name: descripcionpago iddescripcion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.descripcionpago ALTER COLUMN iddescripcion SET DEFAULT nextval('public.descripcionpago_iddescripcion_seq'::regclass);


--
-- Name: descripcionventa iddescripcion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.descripcionventa ALTER COLUMN iddescripcion SET DEFAULT nextval('public.descripcionventa_iddescripcion_seq'::regclass);


--
-- Name: establecimientos idestablecimiento; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.establecimientos ALTER COLUMN idestablecimiento SET DEFAULT nextval('public.establecimientos_idestablecimiento_seq'::regclass);


--
-- Name: inventario idinventario; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventario ALTER COLUMN idinventario SET DEFAULT nextval('public.inventario_idinventario_seq'::regclass);


--
-- Name: logcliente idlog; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logcliente ALTER COLUMN idlog SET DEFAULT nextval('public.logcliente_idlog_seq'::regclass);


--
-- Name: logcotizacion idlog; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logcotizacion ALTER COLUMN idlog SET DEFAULT nextval('public.logcotizacion_idlog_seq'::regclass);


--
-- Name: logpago idlog; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logpago ALTER COLUMN idlog SET DEFAULT nextval('public.logpago_idlog_seq'::regclass);


--
-- Name: logventa idlog; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logventa ALTER COLUMN idlog SET DEFAULT nextval('public.logventa_idlog_seq'::regclass);


--
-- Name: marcas idmarca; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marcas ALTER COLUMN idmarca SET DEFAULT nextval('public.marcas_idmarca_seq'::regclass);


--
-- Name: pagos idpago; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pagos ALTER COLUMN idpago SET DEFAULT nextval('public.pagos_idpago_seq'::regclass);


--
-- Name: peticiones idpeticion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.peticiones ALTER COLUMN idpeticion SET DEFAULT nextval('public.peticiones_idpeticion_seq'::regclass);


--
-- Name: proveedores idproveedor; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proveedores ALTER COLUMN idproveedor SET DEFAULT nextval('public.proveedores_idproveedor_seq'::regclass);


--
-- Name: reportearticulo idreportearticulo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reportearticulo ALTER COLUMN idreportearticulo SET DEFAULT nextval('public.reportearticulo_idreportearticulo_seq'::regclass);


--
-- Name: reporteclientemasingresos idreportecliente; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporteclientemasingresos ALTER COLUMN idreportecliente SET DEFAULT nextval('public.reporteclientemasingresos_idreportecliente_seq'::regclass);


--
-- Name: reportevendedor idreportevendedor; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reportevendedor ALTER COLUMN idreportevendedor SET DEFAULT nextval('public.reportevendedor_idreportevendedor_seq'::regclass);


--
-- Name: tipoarticulo idtipoart; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipoarticulo ALTER COLUMN idtipoart SET DEFAULT nextval('public.tipoarticulo_idtipoart_seq'::regclass);


--
-- Name: tipoestablecimiento idtipo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipoestablecimiento ALTER COLUMN idtipo SET DEFAULT nextval('public.tipoestablecimiento_idtipo_seq'::regclass);


--
-- Name: tipopago idtipo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipopago ALTER COLUMN idtipo SET DEFAULT nextval('public.tipopago_idtipo_seq'::regclass);


--
-- Name: tipousuario idtipo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipousuario ALTER COLUMN idtipo SET DEFAULT nextval('public.tipousuario_idtipo_seq'::regclass);


--
-- Name: usuarios idusuario; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN idusuario SET DEFAULT nextval('public.usuarios_idusuario_seq'::regclass);


--
-- Name: ventas idventa; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventas ALTER COLUMN idventa SET DEFAULT nextval('public.ventas_idventa_seq'::regclass);


--
-- Data for Name: articulos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.articulos (idarticulo, nombremodelo, idtipoarticulo, idmarca, precio) FROM stdin;
\.
COPY public.articulos (idarticulo, nombremodelo, idtipoarticulo, idmarca, precio) FROM '$$PATH$$/2451.dat';

--
-- Data for Name: clienteempresa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clienteempresa (idclienteempresa, idcliente) FROM stdin;
\.
COPY public.clienteempresa (idclienteempresa, idcliente) FROM '$$PATH$$/2455.dat';

--
-- Data for Name: clientepersona; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clientepersona (idclientepersona, idcliente) FROM stdin;
\.
COPY public.clientepersona (idclientepersona, idcliente) FROM '$$PATH$$/2454.dat';

--
-- Data for Name: clientes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clientes (idcliente, nombre, direccion, correo, telefono) FROM stdin;
\.
COPY public.clientes (idcliente, nombre, direccion, correo, telefono) FROM '$$PATH$$/2453.dat';

--
-- Data for Name: cotizacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cotizacion (idcotizacion, descripcion, idcliente, idusuario, fecha) FROM stdin;
\.
COPY public.cotizacion (idcotizacion, descripcion, idcliente, idusuario, fecha) FROM '$$PATH$$/2461.dat';

--
-- Data for Name: descripcioncotizacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.descripcioncotizacion (iddescripcion, idcotizacion, idarticulo, cantidad, total) FROM stdin;
\.
COPY public.descripcioncotizacion (iddescripcion, idcotizacion, idarticulo, cantidad, total) FROM '$$PATH$$/2463.dat';

--
-- Data for Name: descripcionpago; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.descripcionpago (iddescripcion, idpago, idarticulo, cantidad, total) FROM stdin;
\.
COPY public.descripcionpago (iddescripcion, idpago, idarticulo, cantidad, total) FROM '$$PATH$$/2471.dat';

--
-- Data for Name: descripcionventa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.descripcionventa (iddescripcion, idventa, idarticulo, cantidad, total) FROM stdin;
\.
COPY public.descripcionventa (iddescripcion, idventa, idarticulo, cantidad, total) FROM '$$PATH$$/2467.dat';

--
-- Data for Name: establecimientos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.establecimientos (idestablecimiento, idtipo, nombre, direccion, encargado) FROM stdin;
\.
COPY public.establecimientos (idestablecimiento, idtipo, nombre, direccion, encargado) FROM '$$PATH$$/2483.dat';

--
-- Data for Name: inventario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventario (idinventario, idarticulo, cantidad, idlocal) FROM stdin;
\.
COPY public.inventario (idinventario, idarticulo, cantidad, idlocal) FROM '$$PATH$$/2485.dat';

--
-- Data for Name: logcliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.logcliente (idlog, idcliente, fecha, hora) FROM stdin;
\.
COPY public.logcliente (idlog, idcliente, fecha, hora) FROM '$$PATH$$/2477.dat';

--
-- Data for Name: logcotizacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.logcotizacion (idlog, idcotizacion, fecha, hora) FROM stdin;
\.
COPY public.logcotizacion (idlog, idcotizacion, fecha, hora) FROM '$$PATH$$/2475.dat';

--
-- Data for Name: logpago; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.logpago (idlog, idpago, fecha, hora) FROM stdin;
\.
COPY public.logpago (idlog, idpago, fecha, hora) FROM '$$PATH$$/2479.dat';

--
-- Data for Name: logventa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.logventa (idlog, idventa, fecha, hora) FROM stdin;
\.
COPY public.logventa (idlog, idventa, fecha, hora) FROM '$$PATH$$/2473.dat';

--
-- Data for Name: marcas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marcas (idmarca, nombre) FROM stdin;
\.
COPY public.marcas (idmarca, nombre) FROM '$$PATH$$/2447.dat';

--
-- Data for Name: pagos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pagos (idpago, descripcion, idproveedor, idusuario, idtipopago, fecha) FROM stdin;
\.
COPY public.pagos (idpago, descripcion, idproveedor, idusuario, idtipopago, fecha) FROM '$$PATH$$/2469.dat';

--
-- Data for Name: peticiones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.peticiones (idpeticion, idarticulo, localorigen, localdestino, idusuario) FROM stdin;
\.
COPY public.peticiones (idpeticion, idarticulo, localorigen, localdestino, idusuario) FROM '$$PATH$$/2493.dat';

--
-- Data for Name: proveedores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.proveedores (idproveedor, nombre) FROM stdin;
\.
COPY public.proveedores (idproveedor, nombre) FROM '$$PATH$$/2457.dat';

--
-- Data for Name: reportearticulo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reportearticulo (idreportearticulo, idarticulo, cantidad, montototal) FROM stdin;
\.
COPY public.reportearticulo (idreportearticulo, idarticulo, cantidad, montototal) FROM '$$PATH$$/2489.dat';

--
-- Data for Name: reporteclientemasingresos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reporteclientemasingresos (idreportecliente, idcliente, montopromedio) FROM stdin;
\.
COPY public.reporteclientemasingresos (idreportecliente, idcliente, montopromedio) FROM '$$PATH$$/2491.dat';

--
-- Data for Name: reportevendedor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reportevendedor (idreportevendedor, idvendedor, cantidadventas, montototal) FROM stdin;
\.
COPY public.reportevendedor (idreportevendedor, idvendedor, cantidadventas, montototal) FROM '$$PATH$$/2487.dat';

--
-- Data for Name: tipoarticulo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipoarticulo (idtipoart, nombre) FROM stdin;
\.
COPY public.tipoarticulo (idtipoart, nombre) FROM '$$PATH$$/2449.dat';

--
-- Data for Name: tipoestablecimiento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipoestablecimiento (idtipo, nombre) FROM stdin;
\.
COPY public.tipoestablecimiento (idtipo, nombre) FROM '$$PATH$$/2481.dat';

--
-- Data for Name: tipopago; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipopago (idtipo, tipo) FROM stdin;
\.
COPY public.tipopago (idtipo, tipo) FROM '$$PATH$$/2459.dat';

--
-- Data for Name: tipousuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipousuario (idtipo, nombre) FROM stdin;
\.
COPY public.tipousuario (idtipo, nombre) FROM '$$PATH$$/2443.dat';

--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuarios (idusuario, "contraseña", idtipo, nombres, apellidos, cedula, fechanacimiento, profesion, correo, usuario) FROM stdin;
\.
COPY public.usuarios (idusuario, "contraseña", idtipo, nombres, apellidos, cedula, fechanacimiento, profesion, correo, usuario) FROM '$$PATH$$/2445.dat';

--
-- Data for Name: ventas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ventas (idventa, descripcion, idcliente, idusuario, idtipopago, fecha) FROM stdin;
\.
COPY public.ventas (idventa, descripcion, idcliente, idusuario, idtipopago, fecha) FROM '$$PATH$$/2465.dat';

--
-- Name: articulos_idarticulo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.articulos_idarticulo_seq', 7, true);


--
-- Name: clientes_idcliente_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.clientes_idcliente_seq', 1, false);


--
-- Name: cotizacion_idcotizacion_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cotizacion_idcotizacion_seq', 1, false);


--
-- Name: descripcioncotizacion_iddescripcion_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.descripcioncotizacion_iddescripcion_seq', 1, false);


--
-- Name: descripcionpago_iddescripcion_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.descripcionpago_iddescripcion_seq', 1, false);


--
-- Name: descripcionventa_iddescripcion_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.descripcionventa_iddescripcion_seq', 1, false);


--
-- Name: establecimientos_idestablecimiento_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.establecimientos_idestablecimiento_seq', 5, true);


--
-- Name: inventario_idinventario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventario_idinventario_seq', 1, false);


--
-- Name: logcliente_idlog_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.logcliente_idlog_seq', 1, false);


--
-- Name: logcotizacion_idlog_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.logcotizacion_idlog_seq', 1, false);


--
-- Name: logpago_idlog_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.logpago_idlog_seq', 1, false);


--
-- Name: logventa_idlog_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.logventa_idlog_seq', 1, false);


--
-- Name: marcas_idmarca_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.marcas_idmarca_seq', 3, true);


--
-- Name: pagos_idpago_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pagos_idpago_seq', 1, false);


--
-- Name: peticiones_idpeticion_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.peticiones_idpeticion_seq', 1, false);


--
-- Name: proveedores_idproveedor_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.proveedores_idproveedor_seq', 1, false);


--
-- Name: reportearticulo_idreportearticulo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reportearticulo_idreportearticulo_seq', 1, false);


--
-- Name: reporteclientemasingresos_idreportecliente_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reporteclientemasingresos_idreportecliente_seq', 1, false);


--
-- Name: reportevendedor_idreportevendedor_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reportevendedor_idreportevendedor_seq', 1, false);


--
-- Name: tipoarticulo_idtipoart_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipoarticulo_idtipoart_seq', 2, true);


--
-- Name: tipoestablecimiento_idtipo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipoestablecimiento_idtipo_seq', 3, true);


--
-- Name: tipopago_idtipo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipopago_idtipo_seq', 1, false);


--
-- Name: tipousuario_idtipo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipousuario_idtipo_seq', 4, true);


--
-- Name: usuarios_idusuario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuarios_idusuario_seq', 7, true);


--
-- Name: ventas_idventa_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ventas_idventa_seq', 1, false);


--
-- Name: articulos articulos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulos
    ADD CONSTRAINT articulos_pkey PRIMARY KEY (idarticulo);


--
-- Name: clienteempresa clienteempresa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clienteempresa
    ADD CONSTRAINT clienteempresa_pkey PRIMARY KEY (idclienteempresa);


--
-- Name: clientepersona clientepersona_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clientepersona
    ADD CONSTRAINT clientepersona_pkey PRIMARY KEY (idclientepersona);


--
-- Name: clientes clientes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (idcliente);


--
-- Name: cotizacion cotizacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cotizacion
    ADD CONSTRAINT cotizacion_pkey PRIMARY KEY (idcotizacion);


--
-- Name: descripcioncotizacion descripcioncotizacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.descripcioncotizacion
    ADD CONSTRAINT descripcioncotizacion_pkey PRIMARY KEY (iddescripcion);


--
-- Name: descripcionpago descripcionpago_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.descripcionpago
    ADD CONSTRAINT descripcionpago_pkey PRIMARY KEY (iddescripcion);


--
-- Name: descripcionventa descripcionventa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.descripcionventa
    ADD CONSTRAINT descripcionventa_pkey PRIMARY KEY (iddescripcion);


--
-- Name: establecimientos establecimientos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.establecimientos
    ADD CONSTRAINT establecimientos_pkey PRIMARY KEY (idestablecimiento);


--
-- Name: inventario inventario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventario
    ADD CONSTRAINT inventario_pkey PRIMARY KEY (idinventario);


--
-- Name: logcliente logcliente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logcliente
    ADD CONSTRAINT logcliente_pkey PRIMARY KEY (idlog);


--
-- Name: logcotizacion logcotizacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logcotizacion
    ADD CONSTRAINT logcotizacion_pkey PRIMARY KEY (idlog);


--
-- Name: logpago logpago_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logpago
    ADD CONSTRAINT logpago_pkey PRIMARY KEY (idlog);


--
-- Name: logventa logventa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logventa
    ADD CONSTRAINT logventa_pkey PRIMARY KEY (idlog);


--
-- Name: marcas marcas_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marcas
    ADD CONSTRAINT marcas_nombre_key UNIQUE (nombre);


--
-- Name: marcas marcas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marcas
    ADD CONSTRAINT marcas_pkey PRIMARY KEY (idmarca);


--
-- Name: pagos pagos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pagos
    ADD CONSTRAINT pagos_pkey PRIMARY KEY (idpago);


--
-- Name: peticiones peticiones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.peticiones
    ADD CONSTRAINT peticiones_pkey PRIMARY KEY (idpeticion);


--
-- Name: proveedores proveedores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proveedores
    ADD CONSTRAINT proveedores_pkey PRIMARY KEY (idproveedor);


--
-- Name: reportearticulo reportearticulo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reportearticulo
    ADD CONSTRAINT reportearticulo_pkey PRIMARY KEY (idreportearticulo);


--
-- Name: reporteclientemasingresos reporteclientemasingresos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporteclientemasingresos
    ADD CONSTRAINT reporteclientemasingresos_pkey PRIMARY KEY (idreportecliente);


--
-- Name: reportevendedor reportevendedor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reportevendedor
    ADD CONSTRAINT reportevendedor_pkey PRIMARY KEY (idreportevendedor);


--
-- Name: tipoarticulo tipoarticulo_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipoarticulo
    ADD CONSTRAINT tipoarticulo_nombre_key UNIQUE (nombre);


--
-- Name: tipoarticulo tipoarticulo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipoarticulo
    ADD CONSTRAINT tipoarticulo_pkey PRIMARY KEY (idtipoart);


--
-- Name: tipoestablecimiento tipoestablecimiento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipoestablecimiento
    ADD CONSTRAINT tipoestablecimiento_pkey PRIMARY KEY (idtipo);


--
-- Name: tipopago tipopago_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipopago
    ADD CONSTRAINT tipopago_pkey PRIMARY KEY (idtipo);


--
-- Name: tipousuario tipousuario_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipousuario
    ADD CONSTRAINT tipousuario_nombre_key UNIQUE (nombre);


--
-- Name: tipousuario tipousuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipousuario
    ADD CONSTRAINT tipousuario_pkey PRIMARY KEY (idtipo);


--
-- Name: usuarios usuarios_cedula_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_cedula_key UNIQUE (cedula);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (idusuario);


--
-- Name: ventas ventas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventas
    ADD CONSTRAINT ventas_pkey PRIMARY KEY (idventa);


--
-- Name: articulos articulos_idmarca_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulos
    ADD CONSTRAINT articulos_idmarca_fkey FOREIGN KEY (idmarca) REFERENCES public.marcas(idmarca);


--
-- Name: articulos articulos_idtipoarticulo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulos
    ADD CONSTRAINT articulos_idtipoarticulo_fkey FOREIGN KEY (idtipoarticulo) REFERENCES public.tipoarticulo(idtipoart);


--
-- Name: clienteempresa clienteempresa_idcliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clienteempresa
    ADD CONSTRAINT clienteempresa_idcliente_fkey FOREIGN KEY (idcliente) REFERENCES public.clientes(idcliente);


--
-- Name: clientepersona clientepersona_idcliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clientepersona
    ADD CONSTRAINT clientepersona_idcliente_fkey FOREIGN KEY (idcliente) REFERENCES public.clientes(idcliente);


--
-- Name: cotizacion cotizacion_idcliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cotizacion
    ADD CONSTRAINT cotizacion_idcliente_fkey FOREIGN KEY (idcliente) REFERENCES public.clientes(idcliente);


--
-- Name: cotizacion cotizacion_idusuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cotizacion
    ADD CONSTRAINT cotizacion_idusuario_fkey FOREIGN KEY (idusuario) REFERENCES public.usuarios(idusuario);


--
-- Name: descripcioncotizacion descripcioncotizacion_idarticulo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.descripcioncotizacion
    ADD CONSTRAINT descripcioncotizacion_idarticulo_fkey FOREIGN KEY (idarticulo) REFERENCES public.articulos(idarticulo);


--
-- Name: descripcioncotizacion descripcioncotizacion_idcotizacion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.descripcioncotizacion
    ADD CONSTRAINT descripcioncotizacion_idcotizacion_fkey FOREIGN KEY (idcotizacion) REFERENCES public.cotizacion(idcotizacion);


--
-- Name: descripcionpago descripcionpago_idarticulo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.descripcionpago
    ADD CONSTRAINT descripcionpago_idarticulo_fkey FOREIGN KEY (idarticulo) REFERENCES public.articulos(idarticulo);


--
-- Name: descripcionpago descripcionpago_idpago_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.descripcionpago
    ADD CONSTRAINT descripcionpago_idpago_fkey FOREIGN KEY (idpago) REFERENCES public.pagos(idpago);


--
-- Name: descripcionventa descripcionventa_idarticulo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.descripcionventa
    ADD CONSTRAINT descripcionventa_idarticulo_fkey FOREIGN KEY (idarticulo) REFERENCES public.articulos(idarticulo);


--
-- Name: descripcionventa descripcionventa_idventa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.descripcionventa
    ADD CONSTRAINT descripcionventa_idventa_fkey FOREIGN KEY (idventa) REFERENCES public.ventas(idventa);


--
-- Name: establecimientos establecimientos_encargado_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.establecimientos
    ADD CONSTRAINT establecimientos_encargado_fkey FOREIGN KEY (encargado) REFERENCES public.usuarios(idusuario);


--
-- Name: establecimientos establecimientos_idtipo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.establecimientos
    ADD CONSTRAINT establecimientos_idtipo_fkey FOREIGN KEY (idtipo) REFERENCES public.tipoestablecimiento(idtipo);


--
-- Name: inventario inventario_idarticulo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventario
    ADD CONSTRAINT inventario_idarticulo_fkey FOREIGN KEY (idarticulo) REFERENCES public.articulos(idarticulo);


--
-- Name: inventario inventario_idlocal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventario
    ADD CONSTRAINT inventario_idlocal_fkey FOREIGN KEY (idlocal) REFERENCES public.establecimientos(idestablecimiento);


--
-- Name: logcliente logcliente_idcliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logcliente
    ADD CONSTRAINT logcliente_idcliente_fkey FOREIGN KEY (idcliente) REFERENCES public.clientes(idcliente);


--
-- Name: logcotizacion logcotizacion_idcotizacion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logcotizacion
    ADD CONSTRAINT logcotizacion_idcotizacion_fkey FOREIGN KEY (idcotizacion) REFERENCES public.cotizacion(idcotizacion);


--
-- Name: logpago logpago_idpago_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logpago
    ADD CONSTRAINT logpago_idpago_fkey FOREIGN KEY (idpago) REFERENCES public.pagos(idpago);


--
-- Name: logventa logventa_idventa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logventa
    ADD CONSTRAINT logventa_idventa_fkey FOREIGN KEY (idventa) REFERENCES public.ventas(idventa);


--
-- Name: pagos pagos_idproveedor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pagos
    ADD CONSTRAINT pagos_idproveedor_fkey FOREIGN KEY (idproveedor) REFERENCES public.proveedores(idproveedor);


--
-- Name: pagos pagos_idtipopago_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pagos
    ADD CONSTRAINT pagos_idtipopago_fkey FOREIGN KEY (idtipopago) REFERENCES public.tipopago(idtipo);


--
-- Name: pagos pagos_idusuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pagos
    ADD CONSTRAINT pagos_idusuario_fkey FOREIGN KEY (idusuario) REFERENCES public.usuarios(idusuario);


--
-- Name: peticiones peticiones_idarticulo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.peticiones
    ADD CONSTRAINT peticiones_idarticulo_fkey FOREIGN KEY (idarticulo) REFERENCES public.articulos(idarticulo);


--
-- Name: peticiones peticiones_idusuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.peticiones
    ADD CONSTRAINT peticiones_idusuario_fkey FOREIGN KEY (idusuario) REFERENCES public.usuarios(idusuario);


--
-- Name: peticiones peticiones_localdestino_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.peticiones
    ADD CONSTRAINT peticiones_localdestino_fkey FOREIGN KEY (localdestino) REFERENCES public.establecimientos(idestablecimiento);


--
-- Name: peticiones peticiones_localorigen_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.peticiones
    ADD CONSTRAINT peticiones_localorigen_fkey FOREIGN KEY (localorigen) REFERENCES public.establecimientos(idestablecimiento);


--
-- Name: reportearticulo reportearticulo_idarticulo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reportearticulo
    ADD CONSTRAINT reportearticulo_idarticulo_fkey FOREIGN KEY (idarticulo) REFERENCES public.articulos(idarticulo);


--
-- Name: reporteclientemasingresos reporteclientemasingresos_idcliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporteclientemasingresos
    ADD CONSTRAINT reporteclientemasingresos_idcliente_fkey FOREIGN KEY (idcliente) REFERENCES public.clientes(idcliente);


--
-- Name: reportevendedor reportevendedor_idvendedor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reportevendedor
    ADD CONSTRAINT reportevendedor_idvendedor_fkey FOREIGN KEY (idvendedor) REFERENCES public.usuarios(idusuario);


--
-- Name: usuarios usuarios_idtipo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_idtipo_fkey FOREIGN KEY (idtipo) REFERENCES public.tipousuario(idtipo);


--
-- Name: ventas ventas_idcliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventas
    ADD CONSTRAINT ventas_idcliente_fkey FOREIGN KEY (idcliente) REFERENCES public.clientes(idcliente);


--
-- Name: ventas ventas_idtipopago_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventas
    ADD CONSTRAINT ventas_idtipopago_fkey FOREIGN KEY (idtipopago) REFERENCES public.tipopago(idtipo);


--
-- Name: ventas ventas_idusuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventas
    ADD CONSTRAINT ventas_idusuario_fkey FOREIGN KEY (idusuario) REFERENCES public.usuarios(idusuario);


--
-- PostgreSQL database dump complete
--

